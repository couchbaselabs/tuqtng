Sample data for tests, demos, tutorials, etc.

Note: if you modify existing data in these subdirectories, you may
break existing unit-tests.  An alternative would be to make your own
copied subdirectories.
